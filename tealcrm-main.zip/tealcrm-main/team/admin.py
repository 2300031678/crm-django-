from django.contrib import admin

from .models import Team, Plan

admin.site.register(Team)
admin.site.register(Plan)